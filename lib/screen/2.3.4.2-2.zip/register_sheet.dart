import 'package:book_lnr_desc_v2/widget/Button.dart';
import 'package:book_lnr_desc_v2/widget/TitleTextField.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RegisterSheet extends StatefulWidget {
  const RegisterSheet({super.key});

  @override
  State<RegisterSheet> createState() => _RegisterSheetState();
}

class _RegisterSheetState extends State<RegisterSheet> {
  @override
  Widget build(BuildContext context) {
    final emailController = TextEditingController(); // 추가된 컨트롤러
    final passwordController = TextEditingController(); // 추가된 컨트롤러

    return Padding(
      padding:
      EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Wrap(
        children: [
          Stack(
            children: [
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 14.0),
                  child: Text(
                    "회원가입",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.close),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
            child: TitleTextField(
              textEditingController: emailController, // 컨트롤러를 적용한 코드
              hintText: "이메일을 입력해주세요",
              title: "이메일",
              isRequire: true,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
            child: TitleTextField(
              textEditingController: passwordController, // 컨트롤러를 적용한 코드
              hintText: "비밀번호를 입력해주세요",
              title: "비밀번호",
              isRequire: true,
            ),
          ),
          SafeArea(
            minimum: EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            child: Button(
              text: "회원가입",
              onPressed: () {
                print('이메일 >> ${emailController.text}'); // 컨트롤러를 사용해서 입력된 텍스트 값
                print('비밀번호 >> ${passwordController.text}'); // 컨트롤러를 사용해서 입력된 텍스트 값

              },
            ),
          )
        ],
      ),
    );
  }
}
