import 'package:flutter/material.dart';

import '../widget/Button.dart';
import '../widget/TitleTextField.dart';

class RegisterSheet extends StatefulWidget {
  const RegisterSheet({super.key});

  @override
  State<RegisterSheet> createState() => _RegisterSheetState();
}

class _RegisterSheetState extends State<RegisterSheet> {
  @override
  Widget build(BuildContext context) {
    return Wrap(
      children: [
        Stack(
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14.0),
                child: Text(
                  "회원가입",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                onPressed: () {},
                icon: Icon(Icons.close),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
          child: TitleTextField(
            hintText: "이메일을 입력해주세요",
            title: "이메일",
            isRequire: true,
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
          child: TitleTextField(
            hintText: "비밀번호를 입력해주세요",
            title: "비밀번호",
            isRequire: true,
          ),
        ),
        SafeArea(
          minimum: EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
          child: Button(text: "로그인", onPressed: () {  },),
        )
      ],
    );
  }
}

