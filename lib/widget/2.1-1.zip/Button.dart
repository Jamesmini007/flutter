import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  const Button({super.key});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(onPressed: (){}, child: Text('커스텀 버튼'));
  }
}
