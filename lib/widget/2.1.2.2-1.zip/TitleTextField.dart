import 'package:flutter/material.dart';

class TitleTextField extends StatefulWidget {
  const TitleTextField({super.key});

  @override
  State<TitleTextField> createState() => _TitleTextFieldState();
}

class _TitleTextFieldState extends State<TitleTextField> {
  @override
  Widget build(BuildContext context) {
    return TextField();
  }
}
