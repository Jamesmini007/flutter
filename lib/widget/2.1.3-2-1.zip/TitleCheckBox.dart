import 'package:flutter/material.dart';

class TitleCheckbox extends StatefulWidget {
  const TitleCheckbox({super.key});

  @override
  State<TitleCheckbox> createState() => _TitleCheckboxState();
}

class _TitleCheckboxState extends State<TitleCheckbox> {
  @override
  Widget build(BuildContext context) {
    return Checkbox(value: false, onChanged: (value) {});
  }
}
